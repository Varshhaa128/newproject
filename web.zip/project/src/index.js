const express = require("express");
const path = require("path");
const { collection, Submission, Contact, Idea } = require("./mongodb");
const multer = require('multer');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const plainTextPassword = 'myPassword';
const saltRounds = 10;
const jsPath = path.join(__dirname, '../js')

const app = express();
// convert data into json format
app.use(express.json());
// Static file
app.use(express.static("js"));
app.use(express.static("views"));

app.use('/csss', express.static(path.join(__dirname, "./views/csss")));


app.use(express.urlencoded({ extended: false }));
//use EJS as the view engine
app.set("view engine", "ejs");

app.get("/", (req, res) => {
    res.render("index");
});
app.get("/login", (req, res) => {
    res.render("login");
});
app.get("/signup", (req, res) => {
    res.render("signup");
});
app.post("/signup", async(req, res) => {
    const data = {
        name: req.body.name,
        email: req.body.email,
        password: req.body.password
    }

    // Check if the username already exists in the database
    const existingUser = await collection.findOne({ email: data.email });

    if (existingUser) {
        // Email already exists, send alert message and return to login page
        res.send('<script>alert("This email address is already registered."); window.location.href="/login";</script>');
    } else {
        // Hash the password using bcrypt
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(data.password, saltRounds);

        data.password = hashedPassword;

        // Insert the new user into the database
        const userdata = await collection.insertMany(data);
        console.log(userdata);

        res.send('<script>alert("Signup successful! please login"); window.location.href="/login";</script>');
        // Signup successful, redirect to login page

    }
});


// Login user 
app.post("/login", async(req, res) => {
    try {
        const check = await collection.findOne({ email: req.body.email });
        if (!check) {

            res.send('<script>alert("Email not found ! "); window.location.href="/login";</script>');
        } else {



            const isPasswordMatch = await bcrypt.compare(req.body.password, check.password);
            if (!isPasswordMatch) {

                res.send('<script>alert("wrong password! "); window.location.href="/login";</script>');
            } else {
                res.send('<script>alert("login successful! "); window.location.href="/land1";</script>');
                //res.render("land1");
            }
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});


const EMAIL_SENDER = 'ullas78999@gmail.com';
const SMTP_CONFIG = {
    service: 'gmail',
    auth: {
        user: 'ullas78999@gmail.com',
        pass: 'zbgy abzc iapt ydqj'
    }
};

const passwordResetTokens = {};

function sendPasswordResetEmail(email, token) {
    const transporter = nodemailer.createTransport(SMTP_CONFIG);

    const resetLink = `http://localhost:3000/reset?token=${token}`;
    const mailOptions = {
        from: EMAIL_SENDER,
        to: email,
        subject: 'Password Reset',
        text: `Click this link to reset your password: ${resetLink}  ,this link will expire within 1 hour`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
}



app.post('/forgetpassword', async(req, res) => {
    const { email } = req.body;

    const user = await collection.findOne({ email });

    if (!user) {
        return res.send('<script>alert("User not found.! ");window.location.href="/forget";</script>');
    }

    const token = crypto.randomBytes(20).toString('hex');
    const expirationTime = Date.now() + 3600000; // Token expires in 1 hour
    passwordResetTokens[email] = { token, expirationTime };

    sendPasswordResetEmail(email, token);

    res.send('<script>alert("we mailed you to reset your password ");window.location.href="/login";</script>');
});

app.get('/resetpassword', async(req, res) => {
    const { token } = req.query;
    const email = Object.keys(passwordResetTokens).find(
        key => passwordResetTokens[key].token === token
    );

    if (!email) {
        return res.send('<script>alert("Invalid or expired token ");;window.location.href="/reset";</script>');
    }

    if (Date.now() > passwordResetTokens[email].expirationTime) {
        delete passwordResetTokens[email];

        return res.send('<script>alert("Token expired ");;window.location.href="/forget";</script>');
    }

    // Render a form to reset the password
    res.sendFile(__dirname + '/views/reset');
});

app.post('/resetpassword', async(req, res) => {
    const { email, password, Cpassword } = req.body;

    const user = await collection.findOne({ email });
    if (email !== email) {

        return res.send('<script>alert("enter your email.! ");;window.location.href="/reset";</script>');
    }
    if (!user) {
        return res.send('<script>alert("User not found.! ");;window.location.href="/reset";</script>');
    }
    if (password !== Cpassword) {

        res.send('<script>alert("passwords donot match! ");window.location.href="/reset";</script>');
    } else {
        const hashedPassword = await bcrypt.hash(password, 10);
        user.password = hashedPassword;

        delete passwordResetTokens[email];

        await user.save();
        res.send('<script>alert("Password reset successful ");window.location.href="/login";</script>');

    }
});